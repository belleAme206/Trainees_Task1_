import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:untitled/UIofApp.dart';

import 'main.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  signup(String email ,String password)async{
    if(email==""&&password==""){
      uiofapp.CustomAlertBox(context, "Enter requird fild");
    }else{
      UserCredential ? usercredential;
      try{
        usercredential= await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password).then((value){
          Navigator.push(context, MaterialPageRoute(builder:((context) => MyHomePage(title:"HomePage"))));
        });
      }on FirebaseAuthException catch(ex){
        return uiofapp.CustomAlertBox(context,ex.code.toString());
      }
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("SignUp"),centerTitle: true,),
      body: Column(mainAxisAlignment: MainAxisAlignment.center,
        children: [
        uiofapp.CustomTextField(emailController,"Email",Icons.mail , false),
        uiofapp.CustomTextField(passwordController , "Password", Icons.password, true),
        SizedBox(height: 20,),
        uiofapp.CustomButton((){
          signup(emailController.text.toString(),passwordController.text.toString());
        },"Sign Up"),
      ],),

    );
  }
}
