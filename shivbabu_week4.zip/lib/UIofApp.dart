import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
class uiofapp{
  static CustomTextField(TextEditingController controller,String text,IconData icondata,bool tohide){
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 35,vertical: 15),
      child: TextField(
        controller: controller,
        obscureText: tohide,
        decoration: InputDecoration(
            hintText: text,
            suffixIcon: Icon(icondata),
            border: OutlineInputBorder(borderRadius:BorderRadius.circular(25 ))
        ),
      ),
    );
  }
  static CustomButton(VoidCallback voidcallback,String text){
    return SizedBox(height: 50,width: 200,child: ElevatedButton(onPressed:(){ voidcallback();
    },style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)))
       , child: Text(text,style: TextStyle(color: Colors.blue),
    )
    ),
    );
  }
  static CustomAlertBox(BuildContext context ,String text){
    return showDialog(context: context, builder: (BuildContext context){
      return AlertDialog(
        title: Text(text),
        actions: [
          TextButton(onPressed: (){
            Navigator.pop(context);
          }, child: Text("ok"))
        ],
      );

    });
  }
}