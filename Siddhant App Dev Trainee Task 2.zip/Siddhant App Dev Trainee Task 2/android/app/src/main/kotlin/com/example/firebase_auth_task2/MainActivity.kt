package com.example.firebase_auth_task2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
