package com.example.combined_app_task2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
