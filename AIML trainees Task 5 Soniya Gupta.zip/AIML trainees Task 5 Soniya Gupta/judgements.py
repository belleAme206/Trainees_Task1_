import os
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

def setup_browser(driver_path):
    chrome_service = Service(driver_path)
    chrome_options = Options()

    chrome_options.add_argument("--start-maximized")
    return webdriver.Chrome(service=chrome_service, options=chrome_options)

def fetch_pdf_links(driver, url):
    driver.get(url)
    input("🔍 Press Enter once the page is fully loaded...")
    return driver.find_elements(By.XPATH, "//a[contains(@href, '.pdf')]")

def download_pdfs(links, folder):
    os.makedirs( "folder", exist_ok=True)
    for element in links:
        pdf_url = element.get_attribute("href")
        if pdf_url:
            filename = os.path.basename(pdf_url)
            file_path = os.path.join( "folder", filename)
            try:
                print(f"📥 Downloading: {filename}")
                content = requests.get(pdf_url).content
                with open(file_path, "wb") as file:
                    file.write(content)
            except Exception as error:
                print(f"⚠️ Error downloading {filename}: {error}")

def main():
    DRIVER_PATH = r"C:\Apps\chromedriver.exe"
    TARGET_URL = "https://www.sci.gov.in/judgements-judgement-date/"
    OUTPUT_DIR = "files_pdfs"

    browser = setup_browser(DRIVER_PATH)
    try:
        pdf_elements = fetch_pdf_links(browser, TARGET_URL)
        download_pdfs(pdf_elements, OUTPUT_DIR)
        print(f"✅ All files saved in '{OUTPUT_DIR}'")
    finally:
        browser.quit()

if __name__ == "__main__":
    main()